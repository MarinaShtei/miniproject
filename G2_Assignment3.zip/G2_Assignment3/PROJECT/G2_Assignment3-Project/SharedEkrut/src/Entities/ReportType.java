package Entities;

public enum ReportType {
	Order,Stock_Status,Client_Activity
}
